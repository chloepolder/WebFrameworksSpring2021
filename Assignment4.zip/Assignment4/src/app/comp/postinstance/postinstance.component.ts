import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Post } from 'src/app/models/post.model';
import { Token } from 'src/app/models/token.model';
import { UserserviceService } from 'src/app/services/userservice.service';

@Component({
  selector: 'app-postinstance',
  templateUrl: './postinstance.component.html',
  styleUrls: ['./postinstance.component.css']
})
export class PostinstanceComponent implements OnInit {

  userIsLoggedIn = false;
  currentUser: Token|null=null;
  @Input() postInstance:Post | undefined;
  
  constructor(private userService: UserserviceService, private router: Router) {
    let userLoggedIn = this.userService.GetLoggedInUser();
    if (userLoggedIn != null){
      this.userIsLoggedIn = true;
      this.currentUser = userLoggedIn;
    }
    this.userService.UserStateChanged.subscribe((userLoggedIn)=>{
      this.userIsLoggedIn = userLoggedIn;
    });
  }

  ngOnInit(): void {
  }

}
