import { Token } from './token.model';

describe('Token', () => {
  it('should create an instance', () => {
    expect(new Token()).toBeTruthy();
  });
});
