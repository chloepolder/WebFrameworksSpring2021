import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';
import { faSearch, faSleigh } from '@fortawesome/free-solid-svg-icons';
import { UserserviceService } from './userservice.service';

@Injectable({
  providedIn: 'root'
})
export class AuthguardService implements CanActivate {

  constructor(private userService:UserserviceService, private router:Router) { }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean{
    let userInfo = this.userService.GetLoggedInUser();
    if(userInfo === null || new Date (userInfo.exp*1000) < new Date()){
      this.router.navigate(['/login', {msg:'Only authenticated users can access that page. Try logging in here.'}]);
      this.userService.SetUserLoggedOut();
      return false;
    }else{
      return true;
    }
  }
}
