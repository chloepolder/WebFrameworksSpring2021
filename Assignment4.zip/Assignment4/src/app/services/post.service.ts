import { HttpClient, HttpHeaders, HttpRequest } from '@angular/common/http';
import { getSafePropertyAccessString } from '@angular/compiler';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Post } from '../models/post.model';

@Injectable({
  providedIn: 'root'
})
export class PostService {

  constructor(private httpC: HttpClient) { }

  GetPosts(){
    return this.httpC.get<Post[]>(`${environment.BASE_URL}/Posts`);
  }

  CreatePost(postInfo:Post , headers:HttpHeaders){
    return this.httpC.post<Post>(environment.BASE_URL+'/Posts', postInfo, {headers:headers});
  }

  UpdatePost(postId:number, postInfo:Post , headers:HttpHeaders){
    //console.log(postInfo);
    return this.httpC.patch<Post>(environment.BASE_URL+'/Posts/'+postId, postInfo, {headers:headers});
  }

  DeletePost(postId:number, headers:HttpHeaders){
    //console.log(headers);
    return this.httpC.delete<Post>(environment.BASE_URL+'/Posts/'+postId, {headers:headers});
  }
}