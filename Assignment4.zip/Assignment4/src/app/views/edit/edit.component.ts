import { Token } from 'src/app/models/token.model';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Post } from 'src/app/models/post.model';
import { PostService } from 'src/app/services/post.service';
import { UserserviceService } from 'src/app/services/userservice.service';
import { HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {

  postInfo:Post|null=null;
  message:string=' ';
  success:boolean= true;
  currentUser: Token|null=null;

  constructor(private postService:PostService, private userService: UserserviceService, private router:Router, private route:ActivatedRoute) {
    this.postInfo= new Post(0,'','','','','','');
    if(this.route.snapshot.paramMap.get('msg'))
    {
      this.message = this.route.snapshot.paramMap.get('msg') as string;
    }
    let userLoggedIn = this.userService.GetLoggedInUser();
    if (userLoggedIn != null){
      this.currentUser = userLoggedIn;
    }
  }

  ngOnInit(): void {
  }

  UpdatePost(){
    if(this.postInfo !== null){
      this.postInfo!.postId = Number(this.route.snapshot.paramMap.get('id'));
      //console.log(this.postInfo);
      let tokenString = localStorage.getItem('token');
      if (tokenString !== null){
        let tokenObj = JSON.parse(tokenString) as {token: string};
        const headers = new HttpHeaders({'token': tokenObj.token});
        this.postService.UpdatePost(this.postInfo!.postId, this.postInfo, headers).subscribe((response)=>{
          console.log(response);
          this.success = true;
          this.router.navigate(['/home', {msg:'Your post was updated.'}]);
        },(error)=>{
          this.success = false;
          this.message = error.error.message;
        })
      }
    }

  }
}
