import { HttpHeaders } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Post } from 'src/app/models/post.model';
import { Token } from 'src/app/models/token.model';
import { PostService } from 'src/app/services/post.service';
import { UserserviceService } from 'src/app/services/userservice.service';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {

  postInfo:Post|null=null;
  message:string=' ';
  success:boolean= true;
  currentUser: Token|null=null;

  constructor(private postService:PostService, private userService: UserserviceService, private router:Router, private route:ActivatedRoute){
    this.postInfo= new Post(0,'','','','','','');
    if(this.route.snapshot.paramMap.get('msg'))
    {
      this.message = this.route.snapshot.paramMap.get('msg') as string;
    }
    let userLoggedIn = this.userService.GetLoggedInUser();
    if (userLoggedIn != null){
      this.currentUser = userLoggedIn;
    }
  }

  ngOnInit(): void {
  }

  CreatePost(){
    if(this.postInfo !== null){
      let tokenString = localStorage.getItem('token');
      if (tokenString !== null){
        let tokenObj = JSON.parse(tokenString) as {token: string};
        const headers = new HttpHeaders({'token': tokenObj.token});
        this.postService.CreatePost(this.postInfo, headers).subscribe((response)=>{
          this.success = true;
          this.router.navigate(['/home', {msg:'Your post was created.'}]);
        },(error)=>{
          this.success = false;
          this.message = error.error.message;
        })
      }
    }
  }
}
